# py

- Use Replit or install the latest Python release
- type `cmd` and enter "python yourfilepath.py"
