**Discord server: https://discord.gg/K5xUbuDqmG**

**These bookmarklets are also on: https://schoolcheats.net/blooket**

# tower-of-doom

This cheat only works in tower of doom game mode!

# addCoins.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDUyMjE0L3RvZEFkZENvaW5zLmpz')).then((res) => res.text().then((t) => eval(t)))
```

# lowerEnemyCharisma.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDUyMjE0L3RvZExvd2VyRW5lbXlDaGFyaXNtYS5qcw==')).then((res) => res.text().then((t) => eval(t)))
```

# lowerEnemyStrength.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDUyMjE0L3RvZExvd2VyRW5lbXlTdHJlbmd0aC5qcw==')).then((res) => res.text().then((t) => eval(t)))
```

# lowerEnemyWisdom.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDUyMjE0L3RvZExvd2VyRW5lbXlXaXNkb20uanM=')).then((res) => res.text().then((t) => eval(t)))
```

# lowerAllEnemyStats.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDY2OTkyL3RvZExvd2VyQWxsRW5lbXlTdGF0cy5qcw==')).then((res) => res.text().then((t) => eval(t)))
```
